/**
 * a type class indicates which type a GameObject is .
 * 
 * @author Zhijie Xia
 * @since 3/19/2020
 */
public enum Type {

    Player, Enemy, Enemy1, Enemy2, Rock, Grave, Weapon

}